
rm(list=ls())
dataInput<-read.csv("C:/$2/513/midterm/2018/IBM_Attrition_v3.csv")


# I.	Summarizing each column (e.g. min, max, mean )
summary(dataInput)


# II.	Identifying missing values
print("I find all the missing values are in column D!")
i<-1
pick<-NULL
while(i<=nrow(dataInput)){
  if(anyNA(dataInput[i,])) {
    print(i);
  }
  i<-i+1
}


# III.	Displaying the frequency table of ��Attrition�� vs. ��MaritalStatus�� 
attach(dataInput)
table(Attrition, MaritalStatus)


# IV.	Displaying the scatter plot of ��Age��, ��MaritalStatus�� and ��YearsAtCompany��, one pair at a time
pairs(dataInput[c("Age", "MaritalStatus", "YearsAtCompany")])


# V.	Showing box plots for columns:  ��Age��, ��MaritalStatus�� and ��YearsAtCompany��
boxplot(dataInput[c("Age", "MaritalStatus", "YearsAtCompany")])
hist(dataInput[,"Age"])
# 1=Married, 2=Divorced, 3=Single
hist(as.numeric(dataInput[,"MaritalStatus"]))
hist(dataInput[,"YearsAtCompany"])


# VI.	Replacing the missing values of ��MonthlyIncome�� with the ��mean�� of ��MonthlyIncome��.
m<-round(mean(dataInput[,"MonthlyIncome"], na.rm=T))
dataInput[is.na(dataInput$MonthlyIncome), "MonthlyIncome"]<-m
print(dataInput)

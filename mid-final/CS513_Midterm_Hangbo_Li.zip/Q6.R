#First Name: Hangbo
#Last Name: Li
#ID: 10432871

rm(list=ls())
dataInputOri<-read.csv("C:/$2/513/midterm/2018/IBM_Attrition_v3.csv")

# replacing the missing values with mean
#dataInput[is.na(dataInput$MonthlyIncome), "MonthlyIncome"]<-round(mean(dataInput[,"MonthlyIncome"], na.rm=T))
dataInput<-na.omit(dataInputOri)
# change values in MaritalStatus into number. 1=Married, 2=Divorced, 3=Single
dataInput[,"MaritalStatus"]<-as.numeric(dataInput[,"MaritalStatus"])

# prepare dataInputaset
indexS<-sample(nrow(dataInput), floor(0.3*nrow(dataInput)))
test<-dataInput[indexS,]
training<-dataInput[-indexS,]

# knn
library(class)
predict<-knn(training[,1:5], test[,1:5], training[,6], k=5)
print(predict)
i<-1
error<-1
print(nrow(test))
while(i < nrow(test))
{
  if(predict[i] != test[i,6])
  {
    error <- error + 1
  }
  i <- i + 1
}
print("The error rate is:")
print(error/ nrow(test))

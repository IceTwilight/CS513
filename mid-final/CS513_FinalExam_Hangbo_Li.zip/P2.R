###### Statement ######
#  Company    : Stevens 
#  Project    : Final Exam Question 2 ANN
#  First Name : Hangbo
#  Last Name  : Li
#  Id			    : 10432871
#  Date       : Dec 10, 2018

### clear environment
rm(list = ls())

### 1.Load the Titanic dataset from CANVAS
bcw <-
  read.csv("C:/Users/Administrator/Desktop/513/Titanic_rows.csv"
           , header = TRUE, sep = ',', na.strings = '?', stringsAsFactors = FALSE)
bcw <- na.omit(bcw)
str(bcw)

### 2.Convert the categorical variables to 0,1 indicators
bcw_convert <- as.data.frame (         
  cbind(  Class = ifelse(bcw$Class=="1st",1
                         ,ifelse(bcw$Class=="2nd",2
                                 ,ifelse(bcw$Class=="3rd",3,4)) )
          ,Sex=ifelse(bcw$Sex=="Male",0,1)
          ,Age=ifelse(bcw$Age=="Child",0,1)
          ,Survived=ifelse(bcw$Survived =="No",0,1)
  )
)

### 3.Store every fourth record in a ��test�� dataset starting with the first record
index <-
  seq(1, nrow(bcw_convert), by = 4)

test <- bcw_convert[index, ]
str(test)
test
### 4.Store the rest in the ��training�� dataset
training <- bcw_convert[-index, ]
str(training)

### 5.Use ANN with 6 hidden nodes to classify passengers (survival=1 vs. 0). 
library("neuralnet")
?neuralnet()



net_Titan  <- neuralnet(Survived ~ Class +	Sex + Age 
                      ,data=training
                      , hidden=6, threshold=0.01)




# Plot the neural network
plot(net_Titan)

### 6.Measure the performance of the model against the test data.
net_Titan_results <-compute(net_Titan, test[,-4])
ANN=as.numeric(net_Titan_results$net.result)


ANN_round<-round(ANN)
ANN_cat<-ifelse(ANN<0.5,0,1)




table(Actual=test$Survived,ANN_cat)

wrong<- (test$Survived!=ANN_cat)
rate<-sum(wrong)/length(wrong)
rate

 
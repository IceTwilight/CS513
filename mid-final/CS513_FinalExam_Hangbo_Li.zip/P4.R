###### Statement ######
#  Company    : Stevens 
#  Project    : Final Exam Question 4 C5.0
#  First Name : Hangbo
#  Last Name  : Li
#  Id			    : 10432871
#  Date       : Dec 10, 2018

### clear environment
rm(list = ls())

### 1.Load the Titanic dataset from CANVAS
bcw <-
  read.csv("C:/Users/Administrator/Desktop/513/Titanic_rows.csv"
           , header = TRUE, sep = ',', na.strings = '?', stringsAsFactors = FALSE)
bcw <- na.omit(bcw)

### 2.Store every fourth record in a ��test�� dataset starting with the first record
index <-
  seq(1, nrow(bcw), by = 4)

test <- bcw[index, ]
str(test)
test

### 3.Store the rest in the ��training�� dataset
training <- bcw[-index, ]
str(training)

### 4.Use C5.0 to classify passengers
# C50  classification 
library('C50')
C50_class <- C5.0(factor(Survived) ~ ., data = training)
summary(C50_class )
plot(C50_class)

### 5.Measure the performance of the model against the test data.
C50_predict<-predict( C50_class ,test , type="class" )
table(actual=test[,4],C50=C50_predict)
wrong<- (test[,4]!=C50_predict)
c50_rate<-sum(wrong)/length(test[,4])
c50_rate

###### Statement ######
#  Company    : Stevens 
#  Project    : Final Exam Question 3 Cart
#  First Name : Hangbo
#  Last Name  : Li
#  Id			    : 10432871
#  Date       : Dec 10, 2018

### clear environment
rm(list = ls())

### 1.Load the Titanic dataset from CANVAS
bcw <-
  read.csv("C:/Users/Administrator/Desktop/513/Titanic_rows.csv"
           , header = TRUE, sep = ',', na.strings = '?', stringsAsFactors = FALSE)
bcw <- na.omit(bcw)

### 2.Store every fourth record in a ��test�� dataset starting with the first record
index <-
  seq(1, nrow(bcw), by = 4)

test <- bcw[index, ]
str(test)
test

### 3.Store the rest in the ��training�� dataset
training <- bcw[-index, ]
str(training)

### 4.Use CART to classify passengers
# install.packages("rpart")
# install.packages("rpart.plot")     # Enhanced tree plots
# install.packages("rattle")         # Fancy tree plot
# install.packages("RColorBrewer")   # colors needed for rattle
library(rpart)
library(rpart.plot)  			# Enhanced tree plots
library(rattle)           # Fancy tree plot
library(RColorBrewer)     # colors needed for rattle

CART_class<-rpart(Survived ~.,data=training)
rpart.plot(CART_class)

### 5.Measure the performance of the model against the test data.
Prediction <- predict(CART_class, test[,])
str(Prediction)
head(Prediction)
CART_predict_cat<-ifelse(Prediction[,2]>=0.5,'Yes','No')
table(actual=test$Survived ,CART_predict_cat)

wrong<- (test$Survived!=CART_predict_cat )
error_rate<-sum(wrong)/length(wrong)
error_rate 

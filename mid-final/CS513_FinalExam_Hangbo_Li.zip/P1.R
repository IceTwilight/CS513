###### Statement ######
#  Company    : Stevens 
#  Project    : Final Exam Question 1 Hclust
#  First Name : Hangbo
#  Last Name  : Li
#  Id			    : 10432871
#  Date       : Dec 10, 2018

### clear environment
rm(list = ls())

### load data
bcw <-
  read.csv("C:/Users/Administrator/Desktop/513/NY_Zip.csv"
           , header = TRUE, sep = ',', na.strings = '?', stringsAsFactors = FALSE)

### remove all the records with missing value
bcw <- na.omit(bcw)
str(bcw)

######################################################################################
### Run hclust algorithm #############################################################
### dist ���� Returns_pct1 to Returns_pct6 
dist <- dist(bcw[, c(4, 5, 6, 7, 8, 9)])
str(dist)

### Hcluster (centroid) 
hc_result <- hclust(dist, method = "centroid")
str(hc_result)
plot(hc_result, cex = 0.6, hang = -1)

### in 4 clusters
hclust_4 <- cutree(hc_result, k = 4)
str(hclust_4)

### Tabulate the clustered rows against the total column 
table(hclust_4, bcw[, 10])

######################################################################################
### Run kmeans algorithm #############################################################
### features: Returns_pct1 to Returns_pct6  
features <- bcw[, c(4, 5, 6, 7, 8, 9)]
str(features)

### in 4 clusters
kmeans_result <-
  kmeans(features, centers = 4, nstart = 10)

str(kmeans_result)
str(kmeans_result$cluster)

### Tabulate the clustered rows against the total column  
table(kmeans_result$cluster, bcw[, 10])

######################################################################################
### Tabulate ���� Compare the four clusters for each of the following two methods ######
table(kmeans_result$cluster,Hclust = hclust_4)

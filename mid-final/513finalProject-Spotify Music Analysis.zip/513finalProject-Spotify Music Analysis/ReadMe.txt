Group Member: Group Member.txt


Presentation Slides: Spotify Music Analysis 513final.pptx



------------------------------------- Main Two Parts Group Work ---------------------------------------
Data Analysis: (PPT Slides 7 ~ 21)

   (1) the code is in Data Analysis code folder written in Python3
       
   (2) Run with PyCharm, Jupyter notebook, or command line "python3 filename.py"
       
       Python Environment Configuration:
       (Python3)
       https://www.python.org/downloads/

       (PyCharm)
       https://www.jetbrains.com/pycharm/download/
      
       (Jupyter notebook)
       https://jupyter.readthedocs.io/en/latest/install.html#installing-jupyter-using-anaconda-and-conda
       https://www.tutorialspoint.com/jupyter/ipython_installation.htm
       https://www.anaconda.com/download/


Class Functions application (PPT Slides 22 ~ End)
   (1) k-Nearest-Neighbor ---- KNN.R ------ PPT (23)
   (2) Cart ------------------ Cart.R------ PPT (24) ------- RplotCart.pdf
   (3) C50  ------------------ C50.R ------ PPT (25)
   (4) Neural network--------- ANN.R ------ PPT (26,27)
   (5) Random Forest ---------- RF.R ------ PPT (28)
   (6) Support Vector Machine-- SVM.R------ PPT (29)
   (7) H-Clustering & K-Means-- hclust.R--- PPT (30 ~ End)



